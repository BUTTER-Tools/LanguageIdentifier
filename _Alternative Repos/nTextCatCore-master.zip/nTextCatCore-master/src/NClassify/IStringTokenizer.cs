﻿namespace NClassify
{
    public interface IStringTokenizer : IFeatureExtractor<string, string>
    {
    }
}
