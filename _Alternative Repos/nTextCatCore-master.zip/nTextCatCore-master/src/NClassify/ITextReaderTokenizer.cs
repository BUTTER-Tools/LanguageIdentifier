﻿using System.IO;

namespace NClassify
{
    public interface ITextReaderTokenizer : IFeatureExtractor<TextReader, string>
    {
    }
}
