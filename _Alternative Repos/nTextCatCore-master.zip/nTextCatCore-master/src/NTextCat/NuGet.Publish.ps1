nuget pack NTextCat.csproj -IncludeReferencedProjects -Prop Configuration=Release
NuGet Push YairHalberstadt.NTextCatCore.Lib.0.2.1.1.nupkg