nuget pack NTextCat.csproj -IncludeReferencedProjects -Prop Configuration=Release
NuGet Push IvanAkcheurov.NTextCat.Lib.0.2.1.1.nupkg